package com.example.springbootcrud.controllers;
import com.example.springbootcrud.services.customerService;
import com.example.springbootcrud.models.Customer;

import java.util.ArrayList;
import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.CrossOrigin;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

@CrossOrigin(origins = "*")
@RestController
@RequestMapping("/api")
public class customerController {

	@Autowired
	customerService customerService;
	
	
	@GetMapping("/customerslist")
	public List<Customer> getAllIpo() {
		System.out.println("Get all Customers...");

		List<Customer> customerslist = customerService.getallcustomers();
		
        for(Customer customerObj: customerslist)
        {
        	System.out.println("Id     :"+customerObj.getId());
        	System.out.println("Name   :"+customerObj.getName());
        	System.out.println("E-mail :"+customerObj.getEmail());
        }
		return customerslist;
	}
	
	@PostMapping("/createcustomer")
	public Customer createcustomer(@RequestBody Customer customerObj) {
		
		Customer customer = customerService.createcustomerservice(customerObj);
		return customer;
	}
}
