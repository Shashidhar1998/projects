package com.example.springbootcrud.services;

import java.util.ArrayList;
import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.example.springbootcrud.models.Customer;
import com.example.springbootcrud.repositories.customerrepo;
@Service
public class customerService {

	@Autowired
	customerrepo customerrepository;

	public List<Customer> getallcustomers() {
		List<Customer> customers = new ArrayList<>();
		customerrepository.findAll().forEach(customers::add);
	    return customers;
	}

	public Customer createcustomerservice(Customer customerObj) {
		
		Customer customer = customerrepository.save(customerObj);
      	return customer;
	}
}
