package com.example.StockMarketCharting.Controllers;

import java.io.File;
import java.io.FileInputStream;
import java.io.FileNotFoundException;
import java.io.IOException;
import java.util.ArrayList;
import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.CrossOrigin;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import com.example.StockMarketCharting.Models.Company;
import com.example.StockMarketCharting.Models.IpoPlanned;
import com.example.StockMarketCharting.Models.StockPrice;
import com.example.StockMarketCharting.Services.CompanyService;
import com.example.StockMarketCharting.Services.IpoService;
import com.example.StockMarketCharting.Services.StockPriceService;


import org.apache.poi.ss.usermodel.Cell;
import org.apache.poi.ss.usermodel.Row;
import org.apache.poi.xssf.usermodel.XSSFSheet;
import org.apache.poi.xssf.usermodel.XSSFWorkbook;

@CrossOrigin(origins = "*")
@RestController
@RequestMapping("/StockExchange")
public class AdminController {
	
	@Autowired
	CompanyService adminservice;
	
	@Autowired
	IpoService iposervice;
	
	@Autowired
	StockPriceService stockpriceservice;
	
	
	@GetMapping("/companies")
	public List<Company> getAllCustomers() {
		System.out.println("Get all Customers...");

		List<Company> customers = new ArrayList<>();
		adminservice.findAll().forEach(customers::add);

		return customers;
	}
	
	@GetMapping("/ipolist")
	public List<IpoPlanned> getAllIpo() {
		System.out.println("Get all Customers...");

		List<IpoPlanned> customers = new ArrayList<>();
		iposervice.findAll().forEach(customers::add);

		return customers;
	}
	
	@GetMapping("/upload")
	public List<StockPrice> upload() throws IOException {
		System.out.println("Get all Customers...");

		List<StockPrice> stockpricedata = new ArrayList<>();
		
		FileInputStream file = new FileInputStream(new File("C:\\Users\\765477\\Downloads\\Book1.xlsx")); 
		@SuppressWarnings("resource")
		XSSFWorkbook workbook = new XSSFWorkbook(file); 
		XSSFSheet sheet = workbook.getSheetAt(0); 
        Row row;
        for(int i=1; i<=sheet.getLastRowNum(); i++){  //points to the starting of excel i.e excel first row
            row = (Row) sheet.getRow(i);  //sheet number
            
            
	            String id;
				if( row.getCell(0)==null) { id = "0"; }
	            else id= row.getCell(0).toString();

                   String name;
				if( row.getCell(1)==null) { name = "null";}  //suppose excel cell is empty then its set to 0 the variable
                   else name = row.getCell(1).toString();   //else copies cell data to name variable

                   String address;
				if( row.getCell(2)==null) { address = "null";   }
                   else  address   = row.getCell(2).toString();
	
	   System.out.println("Id :"+id+"     Name :"+name+"    address :"+address);

	
	    	
        }
		file.close();
		stockpriceservice.findAll().forEach(stockpricedata::add);

		return stockpricedata;
	}
	
	

}
