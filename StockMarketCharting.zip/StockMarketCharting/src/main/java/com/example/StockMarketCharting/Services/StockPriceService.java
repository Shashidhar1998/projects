package com.example.StockMarketCharting.Services;

import org.springframework.data.repository.CrudRepository;

import com.example.StockMarketCharting.Models.StockPrice;

public interface StockPriceService extends CrudRepository<StockPrice, Long>{

}
