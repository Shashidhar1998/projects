package com.example.StockMarketCharting.Services;

import org.springframework.data.repository.CrudRepository;

import com.example.StockMarketCharting.Models.Company;

public interface CompanyService extends CrudRepository<Company, Long> {

	
}
