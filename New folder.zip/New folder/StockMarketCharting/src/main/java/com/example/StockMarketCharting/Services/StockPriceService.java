package com.example.StockMarketCharting.Services;

import org.springframework.data.jpa.repository.JpaRepository;

import com.example.StockMarketCharting.Models.StockPrice;

public interface StockPriceService extends JpaRepository<StockPrice, Integer>{

}
