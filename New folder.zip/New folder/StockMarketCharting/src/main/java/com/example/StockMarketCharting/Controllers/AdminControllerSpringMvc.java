package com.example.StockMarketCharting.Controllers;



import java.io.IOException;
import java.text.DateFormat;
import java.text.ParseException;
import java.text.SimpleDateFormat;
import java.util.Date;

import org.apache.poi.xssf.usermodel.XSSFWorkbook;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.multipart.MultipartFile;

import com.example.StockMarketCharting.Models.StockPrice;
import com.example.StockMarketCharting.Services.StockPriceService;
import com.example.StockMarketCharting.Services.UserService;

import org.apache.poi.ss.usermodel.Row;
import org.apache.poi.xssf.usermodel.XSSFSheet;

@Controller
public class AdminControllerSpringMvc {

	
	@Autowired
	UserService userservice;
	
	@Autowired
	StockPriceService stockpriceservice;
	
	
	
	@RequestMapping(value="/uploadstockprice")
	public String uploadexcel(@RequestParam("file") MultipartFile file1) throws IOException, ParseException
	{
	
		    StockPrice Object1 =null;
		 
		    @SuppressWarnings("resource")
			XSSFWorkbook workbook = new XSSFWorkbook(file1.getInputStream());
			XSSFSheet sheet = workbook.getSheetAt(0); 
	        Row row;
	        int numberofRecords = 0;
	        for(int i=1; i<=sheet.getLastRowNum(); i++){  //points to the starting of excel i.e excel first row
	            row = (Row) sheet.getRow(i);  //sheet number
	            
	            
		            String idS;
					if( row.getCell(0)==null) { idS = "0"; }
		            else idS= row.getCell(0).toString();
					
					float id1 = Float.parseFloat(idS),companyid1,stockexchangeid1;
					
					
					
					String companyidS;
					if( row.getCell(1)==null) { companyidS = "0"; }
		            else companyidS= row.getCell(1).toString();

					 companyid1= Float.parseFloat(companyidS);
					
					
					String stockexchangeidS;
					if( row.getCell(2)==null) { stockexchangeidS = "0"; }
		            else stockexchangeidS= row.getCell(2).toString();
					
					 stockexchangeid1= Float.parseFloat(stockexchangeidS);
					
					int id=(int)id1,companyid=(int)companyid1,stockexchangeid=(int)stockexchangeid1;
					
	                   String currentPriceS;
					if( row.getCell(3)==null) { currentPriceS = "0";}  //suppose excel cell is empty then its set to 0 the variable
	                   else currentPriceS = row.getCell(3).toString();   //else copies cell data to name variable

					 float currentPrice = Float.parseFloat(currentPriceS);
					 
					 
					 
	                   String dateinexcelS;
					if( row.getCell(4)==null) { dateinexcelS = "null";   }
	                   else  dateinexcelS   = row.getCell(4).toString();
					
					   
					    Date dateinexcel=new SimpleDateFormat("dd/MM/yyyy").parse(dateinexcelS); 
					
					    
					    
					 String timeinexcelS;
						if( row.getCell(5)==null) { timeinexcelS = "null";   }
		                   else  timeinexcelS   = row.getCell(5).toString();
						
						
						DateFormat sdf = new SimpleDateFormat("hh:mm:ss");
						Date timeinexcel = sdf.parse(timeinexcelS);
		
		   System.out.println("Id :"+id+"companyid :"+companyid+"     stockexchangeid :"+stockexchangeid+
				              "    currentPrice :"+currentPrice+"    dateinexcel :"+dateinexcel+
				              "    timeinexcel :"+timeinexcel);
		    Object1 = new StockPrice(companyid,stockexchangeid,currentPrice,dateinexcel,timeinexcel);
		   
		       numberofRecords++;
		       stockpriceservice.save(Object1);
		       Object1 = null;
	        }
		
            System.out.println("Number of records are :"+numberofRecords);
		
		    
		return "NewFile";
	}
	
	
}
