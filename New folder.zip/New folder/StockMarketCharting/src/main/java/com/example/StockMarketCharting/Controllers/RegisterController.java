package com.example.StockMarketCharting.Controllers;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.servlet.ModelAndView;

import com.example.StockMarketCharting.Models.User;
import com.example.StockMarketCharting.Services.UserService;
@Controller
public class RegisterController {

	
	@Autowired
	UserService userservice;
	
	
	@RequestMapping(value="/signupuser",method = RequestMethod.GET)
	public ModelAndView signupUserDB(@RequestParam("Username")String username, @RequestParam("Password")String password,@RequestParam("E_Mail")String mail,@RequestParam("Contact")String contact)
	{
		
		    int randomPin   =(int)(Math.random()*9000)+1000;
			String otp  =String.valueOf(randomPin);
			System.out.println("OTP : "+otp);
		           
		
		          String message = " Verification Code is : "+otp+"\n Happy Exploring!!"; 
			     String Sent = UserController.send(mail, "Verification code for Stock Exchange", message);
		        // String Sent = "Success";
		         ModelAndView mv = new ModelAndView();
		         if(Sent.contentEquals("Success"))
					{
		        	 
		        	int contact1 = Integer.parseInt(contact);	
		 		    User userObj = new User(username,password,"UC",mail,contact1,otp);
		 		    userservice.save(userObj);
					}
		         
		         else if(Sent.contentEquals("Failure"))
		         {
		        	 System.out.println("Error While Sending message Or Incorrect mail");
		        	 mv.setViewName("SignUpPage");
		         }
			
	
	             return mv;
	}
}
