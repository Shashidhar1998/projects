package com.example.StockMarketCharting.Controllers;

import java.io.File;
import java.io.FileInputStream;
import java.io.IOException;
import java.util.ArrayList;
import java.util.Date;
import java.util.List;
import java.text.DateFormat;
import java.text.ParseException;
import java.text.SimpleDateFormat;  
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.CrossOrigin;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import com.example.StockMarketCharting.Models.Company;
import com.example.StockMarketCharting.Models.IpoPlanned;
import com.example.StockMarketCharting.Models.Sector;
import com.example.StockMarketCharting.Models.StockPrice;
import com.example.StockMarketCharting.Services.CompanyService;
import com.example.StockMarketCharting.Services.IpoService;
import com.example.StockMarketCharting.Services.SectorService;
import com.example.StockMarketCharting.Services.StockPriceService;

import org.apache.poi.ss.usermodel.Row;
import org.apache.poi.xssf.usermodel.XSSFSheet;
import org.apache.poi.xssf.usermodel.XSSFWorkbook;

@CrossOrigin(origins = "*")
@RestController
@RequestMapping("/StockExchange")
public class AdminController {
	
	@Autowired
	CompanyService adminservice;
	
	@Autowired
	IpoService iposervice;
	
	@Autowired
	StockPriceService stockpriceservice;
	
	@Autowired
	SectorService sectorservice;
	
	
	@GetMapping("/companies")
	public List<Company> getAllCustomers() {
		System.out.println("Get all Customers...");

		List<Company> customers = new ArrayList<>();
		adminservice.findAll().forEach(customers::add);

		return customers;
	}
	
	@GetMapping("/ipolist")
	public List<IpoPlanned> getAllIpo() {
		System.out.println("Get all Customers...");

		List<IpoPlanned> customers = new ArrayList<>();
		iposervice.findAll().forEach(customers::add);

		return customers;
	}
	
	@GetMapping("/upload")
	public List<StockPrice> upload() throws IOException, ParseException {
		System.out.println("Get all Customers...");

		List<StockPrice> stockpricedata = new ArrayList<>();
		StockPrice Object1 =null;
		FileInputStream file = new FileInputStream(new File("C:\\Users\\765477\\Downloads\\Book1.xlsx")); 
		@SuppressWarnings("resource")
		XSSFWorkbook workbook = new XSSFWorkbook(file); 
		XSSFSheet sheet = workbook.getSheetAt(0); 
        Row row;
        for(int i=1; i<=sheet.getLastRowNum(); i++){  //points to the starting of excel i.e excel first row
            row = (Row) sheet.getRow(i);  //sheet number
            
            
	            String idS;
				if( row.getCell(0)==null) { idS = "0"; }
	            else idS= row.getCell(0).toString();
				
				float id1 = Float.parseFloat(idS),companyid1,stockexchangeid1;
				
				
				
				String companyidS;
				if( row.getCell(1)==null) { companyidS = "0"; }
	            else companyidS= row.getCell(1).toString();

				 companyid1= Float.parseFloat(companyidS);
				
				
				String stockexchangeidS;
				if( row.getCell(2)==null) { stockexchangeidS = "0"; }
	            else stockexchangeidS= row.getCell(2).toString();
				
				 stockexchangeid1= Float.parseFloat(stockexchangeidS);
				
				int id=(int)id1,companyid=(int)companyid1,stockexchangeid=(int)stockexchangeid1;
				
                   String currentPriceS;
				if( row.getCell(3)==null) { currentPriceS = "0";}  //suppose excel cell is empty then its set to 0 the variable
                   else currentPriceS = row.getCell(3).toString();   //else copies cell data to name variable

				 float currentPrice = Float.parseFloat(currentPriceS);
				 
				 
				 
                   String dateinexcelS;
				if( row.getCell(4)==null) { dateinexcelS = "null";   }
                   else  dateinexcelS   = row.getCell(4).toString();
				
				   
				    Date dateinexcel=new SimpleDateFormat("dd/MM/yyyy").parse(dateinexcelS); 
				
				    
				    
				 String timeinexcelS;
					if( row.getCell(5)==null) { timeinexcelS = "null";   }
	                   else  timeinexcelS   = row.getCell(5).toString();
					
					
					DateFormat sdf = new SimpleDateFormat("hh:mm:ss");
					Date timeinexcel = sdf.parse(timeinexcelS);
	
	   System.out.println("Id :"+id+"companyid :"+companyid+"     stockexchangeid :"+stockexchangeid+
			              "    currentPrice :"+currentPrice+"    dateinexcel :"+dateinexcel+
			              "    timeinexcel :"+timeinexcel);
	    Object1 = new StockPrice(id,companyid,stockexchangeid,currentPrice,dateinexcel,timeinexcel);
	   
	       stockpricedata.add(Object1);
	       Object1 = null;
        }
		file.close();
		//stockpriceservice.findAll().forEach(stockpricedata::add);

		return stockpricedata;
	}
	
	
	@GetMapping(value = "sectors/{id}")
	public List<Sector> findByAge(@PathVariable int id) {

		List<Sector> customers = sectorservice.findCompaniesBySector(id);
		return customers;
	}
	

}
