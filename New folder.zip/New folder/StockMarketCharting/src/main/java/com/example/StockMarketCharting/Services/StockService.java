package com.example.StockMarketCharting.Services;

import org.springframework.data.jpa.repository.JpaRepository;

import com.example.StockMarketCharting.Models.Stock;

public interface StockService extends JpaRepository<Stock, Integer> {

}
