package com.example.StockMarketCharting.Services;

import java.util.List;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Query;
import org.springframework.data.repository.query.Param;

import com.example.StockMarketCharting.Models.Sector;

public interface SectorService extends JpaRepository<Sector, Integer>{

	

	@Query("Select c From Sector c where c.id = :id")
	List<Sector> findCompaniesBySector(@Param("id") int id);
	
}
