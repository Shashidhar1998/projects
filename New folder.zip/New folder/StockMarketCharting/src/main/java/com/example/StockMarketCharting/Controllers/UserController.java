package com.example.StockMarketCharting.Controllers;


import java.util.Optional;
import java.util.Properties;

import javax.mail.Message;
import javax.mail.MessagingException;
import javax.mail.PasswordAuthentication;
import javax.mail.Session;
import javax.mail.Transport;
import javax.mail.internet.InternetAddress;
import javax.mail.internet.MimeMessage;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.CrossOrigin;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.PutMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.RestController;

import com.example.StockMarketCharting.Models.User;
import com.example.StockMarketCharting.Services.UserService;

@CrossOrigin(origins = "*")
@RestController
@RequestMapping("/StockExchange1")

public class UserController {

	@Autowired
	UserService userservice;
	

	
	public static String send(String to,String sub,String msg){  
	    //Get properties object    
	    Properties props = new Properties();    
	    String from="shashidharreddy082@gmail.com";
	    String password="Bharath@123"; 
	    props.put("mail.smtp.host", "smtp.gmail.com");    
	    props.put("mail.smtp.socketFactory.port", "465");    
	    props.put("mail.smtp.socketFactory.class",    
	              "javax.net.ssl.SSLSocketFactory");    
	    props.put("mail.smtp.auth", "true");    
	    props.put("mail.smtp.port", "465"); 
	    Session session = Session.getDefaultInstance(props,   
	     new javax.mail.Authenticator() {    
	     protected PasswordAuthentication getPasswordAuthentication() {    
	     return new PasswordAuthentication(from,password);  
	     }    
	    });    
	    //compose message    
	    try {    
	     MimeMessage message = new MimeMessage(session);    
	     message.addRecipient(Message.RecipientType.TO,new InternetAddress(to));    
	     message.setSubject(sub);    
	     message.setText(msg);    
	     //send message  
	     Transport.send(message);    
	     System.out.println("message sent successfully"); 
	     return "Success";
	    } catch (MessagingException e) {
	    	
	    	return "Failure";
	    
	    } 
	}
	

	@PostMapping(value = "/RegisterUser")
	public User postCustomer(@RequestBody User User) {
		
		
		int randomPin   =(int)(Math.random()*9000)+1000;
		String otp  =String.valueOf(randomPin);
		System.out.println("OTP : "+otp);
		// String message = " Verification Code is : "+otp+"\n Happy Exploring!!";
		 //	String Sent = UserController.send("shashidharreddy994@gmail.com", "Verification code for Stock Exchange", message);
		 String Sent ="Success";
		if(Sent.contentEquals("Success"))
		{
			System.out.println("OTP : Success");
			User.setConfirmed(otp);
			User.setUsertype("UU");
		    User User1 = userservice.save(new User( User.getUsername(),User.getPassword(),User.getUsertype(),User.getEmail(),User.getMobilenumber(),User.getConfirmed()));
		    System.out.println("Please Check the mail");
		    return User1;
		}
		else  if(Sent.contentEquals("Failure"))
		{
			System.out.println("Error While Sending message or Email is incorrect");
			User.setUsertype("InValid");
			return User;
		}
		else
		{
			return User;
		}
		
		
	}
	
	@PutMapping("/ConfirmUser/{id}")
	public ResponseEntity<User> updateCustomer(@PathVariable("id") int id,@RequestParam("verificationcode")String verification) {
		System.out.println("Update Customer with ID = " + id + "...");

	
		Optional<User> customerData = userservice.findById(id,verification);

		if (customerData.isPresent()) {
			User _customer = customerData.get();
			_customer.setUsertype("CU");;
		
			return new ResponseEntity<>(userservice.save(_customer), HttpStatus.OK);
		} else {
			return new ResponseEntity<>(HttpStatus.NOT_FOUND);
		}
	}
}
