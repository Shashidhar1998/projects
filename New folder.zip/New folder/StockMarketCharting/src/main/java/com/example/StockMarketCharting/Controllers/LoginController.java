package com.example.StockMarketCharting.Controllers;



import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.servlet.ModelAndView;

import com.example.StockMarketCharting.Models.User;
import com.example.StockMarketCharting.Services.UserService;
@Controller
public class LoginController {

	@Autowired
	UserService userservice;
	
	@RequestMapping(value="/ValidateUser",method = RequestMethod.POST)
	public ModelAndView validateUserInDB(@RequestParam("username")String username, @RequestParam("password")String password)
	{
		System.out.println("Username :" + username);
		System.out.println("Password :" + password);
		User userdata = new User();
		userdata= userservice.findByUserNameAndPassword(username,password);
		 ModelAndView mv = new ModelAndView();
		 System.out.println("After Checking");
		 
         if(userdata == null)
         {
        	 mv.setViewName("NewFile");
			 System.out.println("Inavalid Credentials");
         }
         else if(userdata.getUsertype().equals("A"))
		 {
        	 System.out.println("usertype : "+userdata.getUsertype());
			 System.out.println("Admin Landing page");
			 mv.setViewName("LoginPage");
		 }
		 else if(userdata.getUsertype().equals("CU"))
		 {
			 System.out.println("User Landing page");
			 mv.setViewName("LoginPage");
		 }
		 else if(userdata.getUsertype().equals("UU"))
		 {
			 System.out.println("Unconfirmed user Landing page");
			 mv.setViewName("ConfirmationPage");
			 mv.addObject("username",username);
			 mv.addObject("mail",userdata.getEmail());
			 mv.addObject("UserId",userdata.getId());
		 }
		
		 
         return mv;
	}
}
