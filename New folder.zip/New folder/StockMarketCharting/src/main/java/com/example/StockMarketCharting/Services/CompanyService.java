package com.example.StockMarketCharting.Services;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.repository.CrudRepository;

import com.example.StockMarketCharting.Models.Company;

public interface CompanyService extends JpaRepository<Company, Integer> {

	
}
