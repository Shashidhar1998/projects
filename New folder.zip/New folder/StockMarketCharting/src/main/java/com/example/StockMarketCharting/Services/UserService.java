package com.example.StockMarketCharting.Services;


import java.util.Optional;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Query;

import com.example.StockMarketCharting.Models.User;

public interface UserService extends JpaRepository<User, Integer>{

	@Query("Select c From User c where c.id = :id and c.confirmed = :verification")
	Optional<User> findById(int id, String verification);

	

}
