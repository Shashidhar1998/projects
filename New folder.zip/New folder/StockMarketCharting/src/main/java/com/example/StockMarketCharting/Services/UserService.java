package com.example.StockMarketCharting.Services;


import java.util.Optional;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Query;

import com.example.StockMarketCharting.Models.User;

public interface UserService extends JpaRepository<User, Integer>{

	@Query("Select c From User c where c.id = :id and c.confirmed = :verification")
	Optional<User> findById(int id, String verification);
    
	
	@Query("Select c From User c where c.username = :username and c.password = :password")
	User findByUserNameAndPassword(String username, String password);

	@Query("Select c From User c where c.email = :e_Mail")
	User findByEmail(String e_Mail);

	@Query("Select c From User c where c.username = :username or c.email = :mail  or c.mobilenumber = :contact2")
	Optional<User> findUser(String username, String mail, int contact2);




	

}
