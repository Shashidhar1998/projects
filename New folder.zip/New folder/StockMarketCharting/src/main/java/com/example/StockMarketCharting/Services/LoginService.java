package com.example.StockMarketCharting.Services;

import org.springframework.data.jpa.repository.JpaRepository;

import com.example.StockMarketCharting.Models.User;

public interface LoginService extends JpaRepository<User, Integer>{

}
