package com.example.StockMarketCharting.Services;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Query;

import org.springframework.data.repository.query.Param;

import com.example.StockMarketCharting.Models.StockPrice;

public interface StockPriceService extends JpaRepository<StockPrice, Integer>{

	@Query(value ="Select sum(current_price) from stock_price where company_id in (select Id from Company where sector_id= :id)",nativeQuery=true)
    float findStockPrice(@Param("id") int id);

	@Query(value ="Select sum(current_price) from stock_price where company_id = :id",nativeQuery=true)
	float findCompanyPrice(int id);

}
