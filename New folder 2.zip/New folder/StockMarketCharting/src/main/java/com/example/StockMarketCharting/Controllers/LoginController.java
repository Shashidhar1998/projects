package com.example.StockMarketCharting.Controllers;



import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;

import com.example.StockMarketCharting.Models.User;
import com.example.StockMarketCharting.Services.UserService;

public class LoginController {

	@Autowired
	UserService userservice;
	
	@PostMapping(value = "/Validate")
	public String validate(@RequestBody User user) {
   
		User userdata = new User();
		userdata= userservice.findByUserNameAndPassword(user.getUsername(),user.getPassword());
		System.out.println("UserType   :"+userdata.getUsertype());
		if(userdata.getUsertype().equals("IU"))
		 {
			
			 System.out.println("Inavalid Credentials");
		 }
		else  if(userdata.getUsertype().equals("Error"))
		 {
			
			return "Error page";
			
		 }
		 else  if(userdata.getUsertype().equals("A"))
		 {
			 return "Admin Landing page";
			 		 }
		 else if(userdata.getUsertype().equals("CU"))
		 {
			 return "User Landing page";
			
		 }
		 else if(userdata.getUsertype().equals("UU"))
		 {
			 return "Unconfirmed user Landing page";
			
		 }
		 else {
			 return "Something Wrong";
		 }
		return null;
	}
}
