package com.example.StockMarketCharting.Controllers;

import java.util.Properties;

import javax.mail.Message;
import javax.mail.MessagingException;
import javax.mail.PasswordAuthentication;
import javax.mail.Session;
import javax.mail.Transport;
import javax.mail.internet.InternetAddress;
import javax.mail.internet.MimeMessage;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.servlet.ModelAndView;

import com.example.StockMarketCharting.Models.User;
import com.example.StockMarketCharting.Services.UserService;

@Controller
public class RegisterController {

	
	@Autowired
	UserService userservice;
	
	public static String send(String from,String password,String to,String sub,String msg){  
	    //Get properties object    
	    Properties props = new Properties();    
	      
	    props.put("mail.smtp.host", "smtp.gmail.com");    
	    props.put("mail.smtp.socketFactory.port", "465");    
	    props.put("mail.smtp.socketFactory.class",    
	              "javax.net.ssl.SSLSocketFactory");    
	    props.put("mail.smtp.auth", "true");    
	    props.put("mail.smtp.port", "465"); 
	    Session session = Session.getDefaultInstance(props,   
	     new javax.mail.Authenticator() {    
	     protected PasswordAuthentication getPasswordAuthentication() {    
	     return new PasswordAuthentication(from,password);  
	     }    
	    });    
	    //compose message    
	    try {    
	     MimeMessage message = new MimeMessage(session);    
	     message.addRecipient(Message.RecipientType.TO,new InternetAddress(to));    
	     message.setSubject(sub);    
	     message.setText(msg);    
	     //send message  
	     Transport.send(message);    
	     System.out.println("message sent successfully"); 
	     return "Success";
	    } catch (MessagingException e) {
	    	System.out.println("Error While Sending and \n Error is :"+e);
	    	return "Failure";
	    
	    } 
	}
	
	@RequestMapping(value="/signupuser",method = RequestMethod.POST)
	public ModelAndView signupUserDB(@RequestParam("Username")String username, @RequestParam("Password")String password,@RequestParam("E_Mail")String mail,@RequestParam("Contact")String contact)
	{
		
		    int randomPin   =(int)(Math.random()*9000)+1000;
			String otp  =String.valueOf(randomPin);
			System.out.println("OTP : "+otp);
		           
		
		          String message = " Verification Code is : "+otp+"\n Happy Exploring!!"; 
			    
		          String Sent = RegisterController.send("shashidharreddy082@gmail.com","Bharath@123",mail,"Verification code for Stock Exchange",message);
			     //  = "Success";
		         ModelAndView mv = new ModelAndView();
		       
		         if(Sent.contentEquals("Success"))
					{
		        	 
		        	int contact1 = Integer.parseInt(contact);	
		 		    User userObj = new User(username,password,"UU",mail,contact1,otp);
		 		    userservice.save(userObj);
		 		    mv.setViewName("ConfirmationPage");
		 		   mv.addObject("username",userObj.getUsername());
					 mv.addObject("mail",userObj.getEmail());
					 mv.addObject("UserId",userObj.getId());
					}
		         
		         else if(Sent.contentEquals("Failure"))
		         {
		        	 System.out.println("Error While Sending message Or Incorrect mail");
		        	 mv.setViewName("SignUpPage");
		         }
			
	
	             return mv;
	}
}
