package com.example.StockMarketCharting;



import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class StockMarketChartingApplication {

	public static void main(String[] args) {
		SpringApplication.run(StockMarketChartingApplication.class, args);
		System.out.println("Started...");
		
		
			
		
		 
	
		  
		   
		
	}

}
